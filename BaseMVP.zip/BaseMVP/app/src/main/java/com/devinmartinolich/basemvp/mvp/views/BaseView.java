package com.devinmartinolich.basemvp.mvp.views;

/**
 * Name : BaseView
 * Created by devin on 1/24/18.
 * Modified by
 * Purpose : This view contains all UI events which will be triggered in multiple
 * Fragments/Activities
 */
public interface BaseView extends MvpView
{

}