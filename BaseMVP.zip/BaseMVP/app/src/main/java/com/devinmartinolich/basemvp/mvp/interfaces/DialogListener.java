package com.devinmartinolich.basemvp.mvp.interfaces;

/**
 * Created by devin on 1/24/18.
 */

public interface DialogListener
{
    public void onDismiss();
}
